# M-Pesa WhatsApp Bot Backend

This is a Node.js backend service for a WhatsApp bot that integrates M-Pesa (via Safaricom Daraja API) and optionally Binance payments. Users are required to make a payment before accessing services.

## 📦 Features

- WhatsApp Web automation using `whatsapp-web.js`
- M-Pesa STK Push integration
- Binance (crypto) payment placeholder
- REST API for payment initiation
- Easy deployment to Render or any Node hosting service

## 🔧 Project Structure

- `index.js` – Main application entry point
- `.env.example` – Environment variable setup template
- `package.json` – Project dependencies and scripts

## 🚀 Getting Started

1. Clone this repo and install dependencies:
   ```bash
   npm install
   ```

2. Create a `.env` file based on `.env.example`:
   ```bash
   cp .env.example .env
   ```

3. Run the server:
   ```bash
   npm start
   ```

## 🧾 API Endpoint

- `POST /api/mpesa/stk` – Initiate an M-Pesa STK push

## 🛡 Environment Variables

See `.env.example` for full configuration. You’ll need:
- M-Pesa credentials (Daraja API)
- Callback URL for transaction response

## 📄 License

This project is MIT licensed.