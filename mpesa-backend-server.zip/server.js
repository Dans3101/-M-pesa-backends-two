
const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());

// Sample root route
app.get('/', (req, res) => {
  res.send('M-Pesa Bot Backend is running!');
});

// Sample webhook endpoint for payment confirmation
app.post('/webhook/mpesa', (req, res) => {
  const mpesaData = req.body;
  console.log('M-Pesa Webhook Data:', mpesaData);
  // Process the data here (e.g., update DB, trigger bot)
  res.status(200).send('Received');
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
