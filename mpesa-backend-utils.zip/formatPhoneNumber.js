
function formatPhoneNumber(phoneNumber) {
  // Convert phone to 254 format (e.g., 0712345678 -> 254712345678)
  if (phoneNumber.startsWith("0")) {
    return "254" + phoneNumber.slice(1);
  } else if (phoneNumber.startsWith("+")) {
    return phoneNumber.slice(1);
  } else {
    return phoneNumber;
  }
}

module.exports = formatPhoneNumber;
