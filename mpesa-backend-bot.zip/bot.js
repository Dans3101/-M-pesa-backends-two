const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const { initiateCryptoPayment } = require('./binance');

const client = new Client({
  authStrategy: new LocalAuth(),
  puppeteer: {
    headless: true,
    args: ['--no-sandbox'],
  }
});

let paidUsers = new Set(); // Simulated memory store

client.on('qr', (qr) => {
  console.log('Scan the QR code below to log in:');
  qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
  console.log('✅ WhatsApp bot is ready!');
});

client.on('message', async (message) => {
  const userId = message.from;

  if (!paidUsers.has(userId)) {
    if (message.body.toLowerCase() === 'pay crypto') {
      const response = await initiateCryptoPayment(userId, 2); // 2 USDT
      client.sendMessage(userId, `Please complete payment at: ${response.paymentUrl}`);
    } else if (message.body.toLowerCase().startsWith('paid')) {
      // In a real bot, you'd validate the payment
      paidUsers.add(userId);
      client.sendMessage(userId, '✅ Payment confirmed. You now have access to the bot.');
    } else {
      client.sendMessage(userId, '💳 Please pay first. Type "pay crypto" to get started.');
    }
    return;
  }

  // Handle paid user commands
  if (message.body.toLowerCase() === 'hi') {
    client.sendMessage(userId, '👋 Hello! How can I help you today?');
  } else {
    client.sendMessage(userId, '🤖 You said: ' + message.body);
  }
});

// Auto-view status feature (optional)
client.on('change_state', state => {
  console.log('Bot state changed to', state);
});

client.initialize();