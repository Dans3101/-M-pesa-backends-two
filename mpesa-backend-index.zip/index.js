const express = require("express");
const dotenv = require("dotenv");
const axios = require("axios");
const app = express();
dotenv.config();

app.use(express.json());

const PORT = process.env.PORT || 10000;

// M-Pesa STK Push endpoint
app.post("/api/mpesa/stk", async (req, res) => {
  const { phone, amount } = req.body;

  const shortcode = process.env.MPESA_SHORTCODE;
  const passkey = process.env.MPESA_PASSKEY;
  const timestamp = new Date()
    .toISOString()
    .replace(/[-:TZ.]/g, "")
    .slice(0, 14);
  const password = Buffer.from(shortcode + passkey + timestamp).toString("base64");

  try {
    const tokenResponse = await axios.get(
      "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials",
      {
        auth: {
          username: process.env.MPESA_CONSUMER_KEY,
          password: process.env.MPESA_CONSUMER_SECRET,
        },
      }
    );

    const token = tokenResponse.data.access_token;

    const stkResponse = await axios.post(
      "https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest",
      {
        BusinessShortCode: shortcode,
        Password: password,
        Timestamp: timestamp,
        TransactionType: "CustomerPayBillOnline",
        Amount: amount,
        PartyA: phone,
        PartyB: shortcode,
        PhoneNumber: phone,
        CallBackURL: process.env.CALLBACK_URL,
        AccountReference: "WhatsAppBot",
        TransactionDesc: "Pay to use WhatsApp Bot",
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    res.json({ message: "STK push sent", data: stkResponse.data });
  } catch (error) {
    res.status(500).json({ error: error.message, details: error.response?.data });
  }
});

app.get("/", (req, res) => {
  res.send("M-Pesa Backend is running!");
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});